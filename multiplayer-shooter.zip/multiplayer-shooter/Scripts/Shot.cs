﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Mirror;

public class Shot : NetworkBehaviour
{
    public GameObject explosionEffect;
    public GameObject playerObject;

    void OnCollisionEnter(Collision col){
        Debug.Log("Collision on Shot "+col.gameObject.name);
        Player myPlayerScript = col.gameObject.GetComponent<Player>();
        myPlayerScript.RpcApplyDamage();
        DoExplode();
        Destroy(gameObject);
    }

    void DoExplode(){
        GameObject thisExplosion = Instantiate(explosionEffect, transform.position, transform.rotation);
        NetworkServer.Spawn(thisExplosion);
        Destroy(thisExplosion, 2);
    }


}
