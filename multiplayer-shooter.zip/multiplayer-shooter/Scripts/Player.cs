﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Mirror;
 
public class Player : NetworkBehaviour
{
    private GameObject thisPlayer;
    private static int playerNumber;
    public GameObject healthBar;
    private float health;
    public Camera playerCamera;
    public GameObject gun1;
    public GameObject gun2;
    private float shotTimer;
    public GameObject m_shotPrefab;
    public GameObject explosionEffect;
    private float speed;
    private float drag = 0.3f;
    private int getCurrentPlayerNumber(){
        playerNumber += 1;
        return playerNumber;
    }

    // Start is called before the first frame update
    void Start()
    {
        thisPlayer = gameObject;
        shotTimer = 0;
        health = 0.3f;
        healthBar.transform.localScale = new Vector3(0.1f, health, 0.1f);
        if(isLocalPlayer == true){
            playerCamera.enabled = true;
        }else{
            playerCamera.enabled = false;
        }
    }

    // Update is called once per frame
    void Update()
    {
        if(hasAuthority){      
            transform.Rotate(new Vector3(Input.GetAxis("Vertical"), 0.0f, -Input.GetAxis("Horizontal")) * Time.deltaTime * 30);
            float acc = Input.GetAxis("Fire1") * 5;
            speed += acc * Time.deltaTime;
            if(speed > 10){
                speed = 10;
            }
            if(speed > 0){
                speed -= drag * Time.deltaTime;
            }
            // Fire guns script
            float fire = Input.GetAxis("Fire2");
            if(fire > 0 && shotTimer < 0 && isLocalPlayer){
                CmdFireShot(gun1.transform.position, gun1.transform.forward);
                CmdFireShot(gun2.transform.position, gun2.transform.forward);
                shotTimer = 15;
            }
            shotTimer -= Time.deltaTime * 30;
        }
    }

    [ClientRpc]
    public void RpcApplyDamage(){
        health -= 0.01f;
        if(health < 0){
            // Player is destroyed
            Destroy(thisPlayer);
        }
        Debug.Log("Damage Applied "+ thisPlayer.gameObject.GetInstanceID().ToString());
        healthBar.transform.localScale = new Vector3(0.1f, health, 0.1f);
        GameObject thisExplosion = Instantiate(explosionEffect, transform.position, transform.rotation);
        Destroy(thisExplosion, 2);
    }

    [Command]
    void CmdFireShot(Vector3 gunpos, Vector3 gundir){
        GameObject thisShot = Instantiate(m_shotPrefab, gunpos, m_shotPrefab.transform.rotation);
        NetworkServer.Spawn(thisShot);
        Rigidbody rb = thisShot.GetComponent<Rigidbody>();
        rb.velocity = gundir * 100;
        Destroy(thisShot, 5);
        Debug.Log("FireShot");
    }

    public override void OnStartClient()
    {
        base.OnStartClient();
        int thisPlayerNumber = getCurrentPlayerNumber();
        gameObject.name = "Player " + thisPlayerNumber.ToString();
        Debug.Log("Player Created: " + gameObject.GetInstanceID().ToString());
        if(isLocalPlayer == true){
            thisPlayer = gameObject;
            Transform startPoint = GameObject.Find("PlayerStart"+thisPlayerNumber.ToString()).transform;
            thisPlayer.transform.position = startPoint.position + new Vector3(0.0f,2.0f,0.0f);
            thisPlayer.transform.rotation = startPoint.rotation;
        }
    }

    [Client]
    private void FixedUpdate()
    {
        if(hasAuthority){
            transform.Translate(0,0,speed * Time.deltaTime, Space.Self);
        }
    }

}
