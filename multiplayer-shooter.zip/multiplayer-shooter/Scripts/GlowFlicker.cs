﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GlowFlicker : MonoBehaviour
{
    private Light engineLight;
    // Start is called before the first frame update
    void Start()
    {
        engineLight = GetComponent<Light>();
    }

    // Update is called once per frame
    void Update()
    {
        engineLight.intensity = Random.Range(10.0f, 30.0f); 
    }
}
